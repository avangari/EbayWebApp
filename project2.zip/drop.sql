-- Akshay Vangari 
-- Naren Nagarajappa
-- CS144 Proj 2
use CS144;

DROP TABLE IF EXISTS Categories;
DROP TABLE IF EXISTS Bids;
DROP TABLE IF EXISTS Items;
DROP TABLE IF EXISTS Users;


